Pokemob models should be either x3d or tabula models.

If using x3d:
export the model from blender, things work best if your model is aligned -Y as forward, Z as up.

If using tabula:
Please name the animations (if any) as follows:
idle, flying, walking, sleeping.

For XML animation examples, please see the XML files which can be found here: https://github.com/Thutmose/Pokecube-Models

For adding pokemon stats/information, you can find examples of properly formatted XML here:
https://github.com/Thutmose/Pokecube/blob/master/Pokecube%20Core/src/main/resources/assets/pokecube/database/pokemobs.xml
